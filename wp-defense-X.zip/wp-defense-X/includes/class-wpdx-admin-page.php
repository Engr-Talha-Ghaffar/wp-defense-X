<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPDefenseX_Admin_Page {

    public function init() {
        add_action('admin_menu', [$this, 'add_menu_page']);
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function add_menu_page() {
        add_menu_page(
            'WP Defense X Settings',
            'WP Defense X',
            'manage_options',
            'wpdx-settings',
            [$this, 'settings_page_html'],
            'dashicons-shield', // WP dashicon
            80
        );
    }

    public function register_settings() {
        register_setting('wpdx_settings_group', 'wpdx_max_attempts');
        register_setting('wpdx_settings_group', 'wpdx_lock_time');
    }

    public function settings_page_html() {
        ?>
        <div class="wrap">
            <h1>WP Defense X - Login Security Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('wpdx_settings_group'); ?>
                <?php do_settings_sections('wpdx_settings_group'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Maximum Login Attempts</th>
                        <td>
                            <input type="number" name="wpdx_max_attempts" value="<?php echo esc_attr(get_option('wpdx_max_attempts', 3)); ?>" min="1" max="10" />
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Lock Time (in hours)</th>
                        <td>
                            <input type="number" name="wpdx_lock_time" value="<?php echo esc_attr(get_option('wpdx_lock_time', 12)); ?>" min="1" max="48" />
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}
