<?php

if (!defined('ABSPATH')) {
    exit;
}

class WPDefenseX_Loader {

    public static function init() {
        // Security lock functionality
        require_once plugin_dir_path(__FILE__) . 'class-secure-login-lock.php';
        $secure_login_lock = new Secure_Login_Lock();
        $secure_login_lock->init();

        // Admin menu
        if (is_admin()) {
            require_once plugin_dir_path(__FILE__) . 'class-wpdx-admin-page.php';
            $admin_page = new WPDefenseX_Admin_Page();
            $admin_page->init();
        }
    }
}
