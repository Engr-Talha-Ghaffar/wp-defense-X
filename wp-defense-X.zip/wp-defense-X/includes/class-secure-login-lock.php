<?php

if (!defined('ABSPATH')) {
    exit;
}

class Secure_Login_Lock {

    private $max_attempts;
    private $lock_time;

    public function __construct() {
        // Load values from settings page or use defaults
        $this->max_attempts = intval(get_option('wpdx_max_attempts', 3));
        $this->lock_time = intval(get_option('wpdx_lock_time', 12)) * HOUR_IN_SECONDS;
    }

    public function init() {
        add_filter('authenticate', [$this, 'check_login_attempts'], 30, 3);
        add_action('wp_login_failed', [$this, 'track_failed_login']);
        add_action('login_form', [$this, 'show_remaining_attempts']);
    }

    private function get_ip() {
        // Improved IP detection behind proxies
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } else {
            return $_SERVER['REMOTE_ADDR'];
        }
    }

    public function track_failed_login($username) {
        $ip = $this->get_ip();
        $data = get_transient('sll_' . $ip);

        if (!$data) {
            $data = ['attempts' => 1, 'locked' => false];
        } else {
            $data['attempts']++;
        }

        if ($data['attempts'] >= $this->max_attempts) {
            $data['locked'] = time() + $this->lock_time;
        }

        set_transient('sll_' . $ip, $data, $this->lock_time);
    }

    public function check_login_attempts($user, $username, $password) {
        $ip = $this->get_ip();
        $data = get_transient('sll_' . $ip);

        if ($data && !empty($data['locked']) && time() < $data['locked']) {
            return new WP_Error(
                'locked',
                __('You are temporarily locked out due to too many failed login attempts. Please try again later.', 'wp-defense-x')
            );
        }

        return $user;
    }

    public function show_remaining_attempts() {
        $ip = $this->get_ip();
        $data = get_transient('sll_' . $ip);

        if ($data && empty($data['locked'])) {
            $remaining = $this->max_attempts - $data['attempts'];
            if ($remaining > 0) {
                echo '<div style="color:red; text-align:center; margin-bottom:10px;">';
                echo esc_html("Login Warning: $remaining attempt(s) remaining.");
                echo '</div>';
            }
        }
    }
}
