<?php
/**
 * Plugin Name: WP Defense X
 * Plugin URI:
 * Description: Advanced security firewall and malware protection plugin for WordPress.
 * Version: 1.0
 * Author: Talha Ghaffar
 * Author URI: 
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

// Autoload core loader class
require_once plugin_dir_path(__FILE__) . 'includes/class-wpdx-loader.php';

// Start the plugin
WPDefenseX_Loader::init();
